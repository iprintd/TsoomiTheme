
export const kitChangeType =
  {
    KIT_QUANTITY: 1,
    QUANTITY: 2,
    REMOVE: 3,
    ADD: 4,
    SAVE: 5
  }
